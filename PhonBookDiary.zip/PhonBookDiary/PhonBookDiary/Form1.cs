﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhonBookDiary
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=Phonebooks;Trusted_connection=true;");
        int ID = 0; 
        public Form1()
        {
            InitializeComponent();
        }

        

        private void ClearData()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            pictureBox1.ImageLocation = null;
          
            
            ID = 0;
        }  
        private void Display()
        {
            try
            {

                imgLocation = "";
                pictureBox1.Image = null;
                pictureBox1.ImageLocation = null;

            SqlDataAdapter da = new SqlDataAdapter("Select * from  Phonebook ", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'phoneBooksDataSet.PhoneBook' table. You can move, or remove it, as needed.
            this.phoneBookTableAdapter.Fill(this.phoneBooksDataSet.PhoneBook);
            Display();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {

           
            if (ID != 0)
            {
               SqlCommand cmd  = new SqlCommand("delete Phonebook where ID='"+ID+"'", con);
                con.Open();
                
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                Display();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {

           
            Byte[] img = (Byte[])dataGridView1.CurrentRow.Cells[1].Value;
            MemoryStream ms = new MemoryStream(img);


            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            pictureBox1.Image = Image.FromStream(ms); 
            //pictureBox1.Image = Image.FromStream(ms);  
            
           // panel1.Visible = false;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

      
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {

           
            con.Open();
            SqlDataAdapter adapt = new SqlDataAdapter("select * from Phonebook where Name like '" + textBox6.Text + "%'", con);
            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

       

        private void btnContact_Click(object sender, EventArgs e)
        {
            try
            {

            
            panel2.Visible = true;
            button1.Visible = false;
            ClearData();
            btnSave.Visible = true;
            btnCancel.Visible = true;
            Update.Visible = false;
            Delete.Visible = false;
            pictureBox2.Visible = true;
           pictureBox1.Image = null;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
           
        }

     

        

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {

            
            if (ID != 0)
            {
                SqlCommand cmd = new SqlCommand("delete Phonebook where ID='" + ID + "'", con);
                con.Open();

                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                panel2.Visible = false;
                Display();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void Delete_Click_2(object sender, EventArgs e)
        {
            try
            {

            if (ID != 0)
            {
                SqlCommand cmd = new SqlCommand("delete Phonebook where ID='" + ID + "'", con);
                con.Open();

                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                panel2.Visible = false;
                Display();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void btnSave_Click_2(object sender, EventArgs e)
        {
            try
            {

           
            if (textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
            {
                byte[] images = null;
                pictureBox1.Image = null;
                pictureBox1.ImageLocation = null;
                FileStream Stream = new FileStream(imgLocation,FileMode.Open,FileAccess.Read);
                BinaryReader brs = new BinaryReader(Stream);
                images = brs.ReadBytes((int)Stream.Length);

                SqlCommand cmd = new SqlCommand("Insert Into Phonebook values('" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "',@images)", con);
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@images", images));
                cmd.ExecuteNonQuery();
                dataGridView1.DataSource = null;

                ClearData();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                panel1.Visible = true;
                panel2.Visible = false;
                Display();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click_2(object sender, EventArgs e)
        {
            try
            {

                
           

            if (textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "" && pictureBox1.ImageLocation !="")
            {
                 if(pictureBox1.ImageLocation !=null)
                 { 
                byte[] images = null;
                FileStream Stream = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
                BinaryReader brs = new BinaryReader(Stream);

                images = brs.ReadBytes((int)Stream.Length);

                SqlCommand cmd = new SqlCommand("Update  Phonebook set Name='" + textBox2.Text + "',PhoneNumber='" + textBox4.Text + "',Email='" + textBox3.Text + "',Address='" + textBox5.Text + "',Image= @images where ID='" + ID + "'", con);
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@images", images));
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                panel1.Visible = true;
                panel2.Visible = false;
                Display();
                ClearData();
                 }
                 else
                 {
                     Byte[] img = (Byte[])dataGridView1.CurrentRow.Cells[1].Value;
                     MemoryStream ms = new MemoryStream(img);
                     pictureBox1.Image = Image.FromStream(ms);
                     SqlCommand cmd = new SqlCommand("Update  Phonebook set Name='" + textBox2.Text + "',PhoneNumber='" + textBox4.Text + "',Email='" + textBox3.Text + "',Address='" + textBox5.Text + "',Image= @images where ID='" + ID + "'", con);
                     con.Open();
                     cmd.Parameters.Add(new SqlParameter("@images", img));
                     cmd.ExecuteNonQuery();
                     MessageBox.Show("Record Updated Successfully");
                     con.Close();
                     panel1.Visible = true;
                     panel2.Visible = false;
                     Display();
                     ClearData();

                 }
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            panel2.Visible = false;
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                
            Byte[] img = (Byte[])dataGridView1.CurrentRow.Cells[1].Value;
            MemoryStream ms = new MemoryStream(img);


            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            pictureBox1.Image = Image.FromStream(ms);  
               
            panel2.Visible = true;
            Update.Visible = true;
            Delete.Visible = true;
            btnSave.Visible = false;
            btnCancel.Visible = false;
            button1.Visible = true;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        string imgLocation = "";
        private void btnImage_Click(object sender, EventArgs e)
        {
            try
            {

                pictureBox2.Visible = false;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|All files(*.*)|*.*";
            if(dialog.ShowDialog()==DialogResult.OK)
            {
                imgLocation = dialog.FileName.ToString();
                pictureBox1.ImageLocation = imgLocation;
            }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

       
    }
}
